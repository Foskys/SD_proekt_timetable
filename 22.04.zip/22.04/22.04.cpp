﻿#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm> // Для функции сортировки

using namespace std;

// Структура для предмета
struct Subject {
    int id;
    string specialty;
    int course;
    string number;
    string subnumber;
    int buildingNumber;
    int floorNumber;
    string officeNumber;
    string teacherFirstName;
    string teacherLastName;
    string teacherPosition;
    string subjectName;
    string time;
    string dayOfWeek;
};

// Функция для создания файла с заданной структурой
void createFile(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        file << "ID,Специальность,Курс,Группа,Подгруппа,Номер корпуса,Этаж,Аудитория,Имя преподавателя,Фамилия преподавателя,Должность,Название предмета,Время,День недели\n";
        file.close();
        cout << "Файл \"" << filename << "\" успешно создан.\n";
    }
    else {
        cout << "Ошибка: не удалось создать файл.\n";
    }
}

// Функция для добавления нового предмета в файл
void addSubject(const Subject& subject, const string& filename) {
    ofstream file(filename, ios::app);
    if (file.is_open()) {
        file << subject.id << " | " << subject.specialty << " | " << subject.course << " | " << subject.number << " | " << subject.subnumber << " | "
            << subject.buildingNumber << " | " << subject.floorNumber << " | " << subject.officeNumber << " | "
            << subject.teacherFirstName << " | " << subject.teacherLastName << " | " << subject.teacherPosition << " | "
            << subject.subjectName << " | " << subject.time << " | " << subject.dayOfWeek << "\n";
        file.close();
        cout << "Предмет добавлен в расписание.\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для вывода всех предметов из файла
void displaySchedule(const string& filename) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        cout << "Расписание:\n";
        while (getline(file, line)) {
            cout << line << endl;
        }
        file.close();
    }
    else {
        cout << "Расписание пусто.\n";
    }
}

// Функция для добавления нового столбца в файл
void addColumn(const string& filename, const string& columnName) {
    ifstream inFile(filename);
    if (inFile.is_open()) {
        string line;
        getline(inFile, line);
        line += "," + columnName;
        inFile.close();

        ofstream outFile(filename);
        outFile << line << endl;
        outFile.close();

        cout << "Столбец \"" << columnName << "\" успешно добавлен в файл \"" << filename << "\".\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для удаления столбца из файла
void removeColumn(const string& filename, const string& columnName) {
    ifstream inFile(filename);
    if (inFile.is_open()) {
        string line;
        getline(inFile, line);
        size_t pos = line.find(columnName);
        if (pos != string::npos) {
            size_t startPos = pos;
            size_t endPos = line.find(",", pos);
            if (endPos == string::npos) {
                endPos = line.length();
            }
            line.erase(startPos, endPos - startPos + 1);
        }
        inFile.close();

        ofstream outFile(filename);
        outFile << line << endl;

        while (getline(inFile, line)) {
            size_t pos = line.find(columnName);
            if (pos != string::npos) {
                size_t startPos = pos;
                size_t endPos = line.find(",", pos);
                if (endPos == string::npos) {
                    endPos = line.length();
                }
                line.erase(startPos, endPos - startPos + 1);
            }
            outFile << line << endl;
        }

        outFile.close();

        cout << "Столбец \"" << columnName << "\" успешно удален из файла \"" << filename << "\".\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для поиска предмета по специальности
void searchBySpecialty(const string& filename, const string& specialty) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        bool found = false;
        cout << "Результаты поиска для специальности \"" << specialty << "\":\n";
        while (getline(file, line)) {
            size_t pos = line.find(specialty);
            if (pos != string::npos) {
                cout << line << endl;
                found = true;
            }
        }
        if (!found) {
            cout << "Предметы для специальности \"" << specialty << "\" не найдены в расписании.\n";
        }
        file.close();
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для поиска предмета по курсу
void searchByCourse(const string& filename, int course) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        bool found = false;
        cout << "Результаты поиска для курса " << course << ":\n";
        while (getline(file, line)) {
            size_t pos = line.find(to_string(course) + ",");
            if (pos != string::npos) {
                cout << line << endl;
                found = true;
            }
        }
        if (!found) {
            cout << "Предметы для курса " << course << " не найдены в расписании.\n";
        }
        file.close();
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для поиска предмета по группе
void searchByGroup(const string& filename, const string& group) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        bool found = false;
        cout << "Результаты поиска для группы \"" << group << "\":\n";
        while (getline(file, line)) {
            size_t pos = line.find(group);
            if (pos != string::npos) {
                cout << line << endl;
                found = true;
            }
        }
        if (!found) {
            cout << "Предметы для группы \"" << group << "\" не найдены в расписании.\n";
        }
        file.close();
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для добавления новой записи
void addRecord(const string& filename, const string& record) {
    ofstream file(filename, ios::app);
    if (file.is_open()) {
        file << record << "\n";
        file.close();
        cout << "Запись добавлена в файл \"" << filename << "\".\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для удаления записи из файла
void removeRecord(const string& filename, int lineNumber) {
    ifstream inFile(filename);
    if (inFile.is_open()) {
        string line;
        vector<string> lines;
        while (getline(inFile, line)) {
            lines.push_back(line);
        }
        inFile.close();

        if (lineNumber < 1 || lineNumber > lines.size()) {
            cout << "Ошибка: неверный номер строки.\n";
            return;
        }

        lines.erase(lines.begin() + lineNumber - 1);

        ofstream outFile(filename);
        for (const string& l : lines) {
            outFile << l << endl;
        }
        outFile.close();

        cout << "Запись с номером " << lineNumber << " удалена из файла \"" << filename << "\".\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для добавления нового файла
void addFile(const string& newFilename) {
    ofstream file(newFilename);
    if (file.is_open()) {
        file << "ID,Специальность,Курс,Группа,Подгруппа,Номер корпуса,Этаж,Аудитория,Имя преподавателя,Фамилия преподавателя,Должность,Название предмета,Время,День недели\n";
        file.close();
        cout << "Новый файл \"" << newFilename << "\" успешно создан.\n";
    }
    else {
        cout << "Ошибка: не удалось создать файл.\n";
    }
}

// Функция для редактирования записи
void editRecord(const string& filename, int lineNumber, const string& editedRecord) {
    ifstream inFile(filename);
    if (inFile.is_open()) {
        string line;
        vector<string> lines;
        while (getline(inFile, line)) {
            lines.push_back(line);
        }
        inFile.close();

        if (lineNumber < 1 || lineNumber > lines.size()) {
            cout << "Ошибка: неверный номер строки.\n";
            return;
        }

        lines[lineNumber - 1] = editedRecord;

        ofstream outFile(filename);
        for (const string& l : lines) {
            outFile << l << endl;
        }
        outFile.close();

        cout << "Запись с номером " << lineNumber << " отредактирована в файле \"" << filename << "\".\n";
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для поиска предмета по ID
void searchById(const string& filename, int id) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        bool found = false;
        cout << "Результаты поиска для ID " << id << ":\n";
        while (getline(file, line)) {
            // Разделяем строку по запятой
            stringstream ss(line);
            string token;
            // Получаем первый токен (ID)
            getline(ss, token, ',');
            // Проверяем, соответствует ли токен искомому ID
            if (stoi(token) == id) {
                cout << line << endl;
                found = true;
                break; // Найден нужный элемент, выходим из цикла
            }
        }
        if (!found) {
            cout << "Предмет с ID " << id << " не найден в расписании.\n";
        }
        file.close();
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

// Функция для сравнения двух строк по определенному полю
bool compareRecords(const string& record1, const string& record2, int fieldIndex, bool ascending) {
    stringstream ss1(record1);
    stringstream ss2(record2);
    string token1, token2;
    for (int i = 0; i < fieldIndex; ++i) {
        getline(ss1, token1, ',');
        getline(ss2, token2, ',');
    }
    getline(ss1, token1, ',');
    getline(ss2, token2, ',');
    if (ascending) {
        return token1 < token2;
    }
    else {
        return token1 > token2;
    }
}

// Функция для сортировки записей по заданному полю и направлению
void sortRecords(vector<string>& records, int fieldIndex, bool ascending) {
    if (ascending) {
        sort(records.begin(), records.end(), [&](const string& record1, const string& record2) {
            return compareRecords(record1, record2, fieldIndex, true);
            });
    }
    else {
        sort(records.begin(), records.end(), [&](const string& record1, const string& record2) {
            return compareRecords(record1, record2, fieldIndex, false);
            });
    }
}

void filter_by_course() {
    int lower_bound, upper_bound;
    int choice;
    cout << "Выберите тип фильтрации:\n";
    cout << "1. Диапазон курсов\n";
    cout << "2. Все курсы >=\n";
    cout << "3. Все курсы <=\n";
    cin >> choice;

    switch (choice) {
    case 1:
        cout << "Введите нижнюю границу диапазона: ";
        cin >> lower_bound;
        cout << "Введите верхнюю границу диапазона: ";
        cin >> upper_bound;
        break;
    case 2:
        cout << "Введите число: ";
        cin >> lower_bound;
        upper_bound = 5;
        break;
    case 3:
        cout << "Введите число: ";
        cin >> upper_bound;
        lower_bound = 1;
        break;
    default:
        cout << "Неверный выбор.\n";
        return;
    }

    ifstream file("timetablee.txt");
    if (file.is_open()) {
        string line;
        vector<string> records;
        cout << "Результаты фильтрации по курсу:\n";
        while (getline(file, line)) {
            stringstream ss(line);
            string token;
            getline(ss, token, ',');
            int course = stoi(token);
            if (course >= lower_bound && course <= upper_bound) {
                cout << line << endl;
            }
        }
        file.close();
    }
    else {
        cout << "Ошибка: не удалось открыть файл.\n";
    }
}

int main() {
    setlocale(LC_ALL,"rus");
    int choice;
    while (true) {
        cout << "\nМеню:\n";
        cout << "1. Создать новый файл расписания\n";
        cout << "2. Добавить новый предмет в расписание\n";
        cout << "3. Вывести расписание\n";
        cout << "4. Добавить новый столбец в файл\n";
        cout << "5. Удалить столбец из файла\n";
        cout << "6. Поиск по специальности\n";
        cout << "7. Поиск по курсу\n";
        cout << "8. Поиск по группе\n";
        cout << "9. Добавить новую запись\n";
        cout << "10. Удалить запись из файла\n";
        cout << "11. Добавить новый файл\n";
        cout << "12. Редактировать запись\n";
        cout << "13. Поиск по ID\n";
        cout << "14. Фильтрация по курсу\n";
        cout << "15. Сортировка по полю\n";
        cout << "16. Выход\n";
        cout << "Выберите действие: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            string filename;
            cout << "Введите имя файла: ";
            cin >> filename;
            createFile(filename);
            break;
        }
        case 2: {
            Subject subject;
            cout << "Введите данные предмета:\n";
            cout << "ID: ";
            cin >> subject.id;
            cout << "Специальность: ";
            cin >> subject.specialty;
            cout << "Курс: ";
            cin >> subject.course;
            cout << "Группа: ";
            cin >> subject.number;
            cout << "Подгруппа: ";
            cin >> subject.subnumber;
            cout << "Номер корпуса: ";
            cin >> subject.buildingNumber;
            cout << "Этаж: ";
            cin >> subject.floorNumber;
            cout << "Аудитория: ";
            cin >> subject.officeNumber;
            cout << "Имя преподавателя: ";
            cin >> subject.teacherFirstName;
            cout << "Фамилия преподавателя: ";
            cin >> subject.teacherLastName;
            cout << "Должность преподавателя: ";
            cin >> subject.teacherPosition;
            cout << "Название предмета: ";
            cin >> subject.subjectName;
            cout << "Время: ";
            cin >> subject.time;
            cout << "День недели: ";
            cin >> subject.dayOfWeek;
            addSubject(subject, "timetablee.txt");
            break;
        }
        case 3:
            displaySchedule("timetablee.txt");
            break;
        case 4: {
            string columnName;
            cout << "Введите имя столбца: ";
            cin >> columnName;
            addColumn("timetablee.txt", columnName);
            break;
        }
        case 5: {
            string columnName;
            cout << "Введите имя столбца для удаления: ";
            cin >> columnName;
            removeColumn("timetablee.txt", columnName);
            break;
        }
        case 6: {
            string specialty;
            cout << "Введите специальность для поиска: ";
            cin >> specialty;
            searchBySpecialty("timetablee.txt", specialty);
            break;
        }
        case 7: {
            int course;
            cout << "Введите курс для поиска: ";
            cin >> course;
            searchByCourse("timetablee.txt", course);
            break;
        }
        case 8: {
            string group;
            cout << "Введите группу для поиска: ";
            cin >> group;
            searchByGroup("timetablee.txt", group);
            break;
        }
        case 9: {
            string record;
            cout << "Введите новую запись: ";
            cin.ignore();
            getline(cin, record);
            addRecord("timetablee.txt", record);
            break;
        }
        case 10: {
            int lineNumber;
            cout << "Введите номер записи для удаления: ";
            cin >> lineNumber;
            removeRecord("timetablee.txt", lineNumber);
            break;
        }
        case 11: {
            string newFilename;
            cout << "Введите имя нового файла: ";
            cin >> newFilename;
            addFile(newFilename);
            break;
        }
        case 12: {
            int lineNumber;
            cout << "Введите номер записи для редактирования: ";
            cin >> lineNumber;
            string editedRecord;
            cout << "Введите отредактированную запись: ";
            cin.ignore();
            getline(cin, editedRecord);
            editRecord("timetablee.txt", lineNumber, editedRecord);
            break;
        }
        case 13: {
            int id;
            cout << "Введите ID для поиска: ";
            cin >> id;
            searchById("timetablee.txt", id);
            break;
        }
        case 14: {
            filter_by_course();
            break;
        }
        case 15: {
            int fieldIndex;
            cout << "Выберите поле для сортировки (1 - ID, 2 - Специальность, 3 - Курс, 4 - Группа, 5 - Подгруппа, 6 - Корпус, 7 - Этаж, 8 - Аудитория, 9 - Имя Препода, 10 - Фамилия Препода, 11 - Должность, 12 - Предмет, 13 - Время, 14 - День недели): ";
            cin >> fieldIndex;
            bool ascending;
            cout << "Выберите направление сортировки (0 - по убыванию, 1 - по возрастанию): ";
            cin >> ascending;
            vector<string> records;
            ifstream file("timetablee.txt");
            if (file.is_open()) {
                string line;
                while (getline(file, line)) {
                    records.push_back(line);
                }
                file.close();
                sortRecords(records, fieldIndex - 1, ascending);
                cout << "Результаты сортировки:\n";
                for (const string& record : records) {
                    cout << record << endl;
                }
            }
            else {
                cout << "Ошибка: не удалось открыть файл.\n";
            }
            break;
        }
        case 16:
            cout << "До свидания!\n";
            return 0;
        default:
            cout << "Неверный выбор.\n";
        }
    }

    return 0;
}
